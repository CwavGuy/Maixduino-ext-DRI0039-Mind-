# MindPlus
# maixduino
from board import board_info
from pin import Pin
import maixduino

# Class for DRI0039
class Dri0039:
  global board_info
  global Pin
  # Class Variable
  _PWM1 = board_info.PIN3
  _DIR1 = board_info.PIN4
  _PWM2 = board_info.PIN11
  _DIR2 = board_info.PIN12
  _PWM3 = board_info.PIN5
  _DIR3 = board_info.PIN8
  _PWM4 = board_info.PIN6
  _DIR4 = board_info.PIN7
      
  # The init method or constructor
  def __init__(self,pwm1,dir1,pwm2,dir2,pwm3,dir3,pwm4,dir4):
    global board_info
    global Pin

    self._PWM1 = pwm1
    self._DIR1 = dir1
    self._PWM2 = pwm2
    self._DIR2 = dir2
    self._PWM3 = pwm3
    self._DIR3 = dir3
    self._PWM4 = pwm4
    self._DIR4 = dir4
    Pin.pwm_init(self._PWM1, 10000, 1)
    Pin.pwm_init(self._PWM2, 10000, 2)
    Pin.pwm_init(self._PWM3, 10000, 3)
    Pin.pwm_init(self._PWM4, 10000, 4)
    Pin.pwm_set(self._PWM1, 0)
    Pin.pwm_set(self._PWM2, 0)
    Pin.pwm_set(self._PWM3, 0)
    Pin.pwm_set(self._PWM4, 0)          


  def setSpeed(self,Motor,FR,Speed):
    global board_info
    global Pin

    if (Motor == 1 and FR == 1):
      Pin.digital_write(self._DIR1,0)
      Pin.pwm_set(self._PWM1, Speed)
    elif (Motor == 1 and FR == 2):
      Pin.digital_write(self._DIR1,1)
      Pin.pwm_set(self._PWM1, Speed)
    elif (Motor == 2 and FR == 1):
      Pin.digital_write(self._DIR2,1)
      Pin.pwm_set(self._PWM2, Speed)
    elif (Motor == 2 and FR == 2):
      Pin.digital_write(self._DIR2,0)
      Pin.pwm_set(self._PWM2, Speed)
    elif (Motor == 3 and FR == 1):
      Pin.digital_write(self._DIR3,0)
      Pin.pwm_set(self._PWM3, Speed)
    elif (Motor == 3 and FR == 2):
      Pin.digital_write(self._DIR3,1)
      Pin.pwm_set(self._PWM3, Speed)
    elif (Motor == 4 and FR == 1):
      Pin.digital_write(self._DIR4,1)
      Pin.pwm_set(self._PWM4, Speed)
    elif (Motor == 4 and FR == 2):
      Pin.digital_write(self._DIR4,0)
      Pin.pwm_set(self._PWM4, Speed)
    
  def stop(self,Motor):   
    global board_info
    global Pin
    if Motor == 1:
      Pin.pwm_set(self._PWM1, 0)
    elif Motor == 2:
      Pin.pwm_set(self._PWM2, 0)
    elif Motor == 3:
      Pin.pwm_set(self._PWM3, 0)
    elif Motor == 4:
      Pin.pwm_set(self._PWM4, 0)

